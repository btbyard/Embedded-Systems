/*  ======== gpiointerrupt.c ========
 */

#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// Timer Driver
#include <ti/drivers/Timer.h>

// i2c Driver
#include <ti/drivers/I2C.h>

// UART Driver
#include <ti/drivers/UART.h>

#define DISPLAY(x) UART_write(uart, &output, x);

// Driver Handles - Global variables

// UART Global Variables
char output[64];
int bytesToSend;

//Timer stuff
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;

// Driver Handles - Global variables
UART_Handle uart;

//I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

I2C_Handle i2c;


void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
 TimerFlag = 1;
}

void initTimer(void)
{
 Timer_Params params;
 // Init the driver
 Timer_init();
 // Configure the driver
 Timer_Params_init(&params);
 params.period = 1000000;
 params.periodUnits = Timer_PERIOD_US;
 params.timerMode = Timer_CONTINUOUS_CALLBACK;
 params.timerCallback = timerCallback;
 // Open the driver
 timer0 = Timer_open(CONFIG_TIMER_0, &params);
 if (timer0 == NULL) {
 /* Failed to initialized timer */
 while (1) {}
 }
 if (Timer_start(timer0) == Timer_STATUS_ERROR) {
 /* Failed to start timer */
 while (1) {}
 }
}


/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */

//Declare button variables that change with press
int button0;
int button1;

void gpioButtonFxn0(uint_least8_t index)
{
    //If button 0 is pressed set to 1
    button0 = 1;

}



void gpioButtonFxn1(uint_least8_t index)
{
    //If button 1 is pressed set to 1
    button1 = 1;
}



// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;

    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))
    // Init the driver
    I2C_init();

    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"))
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"));
   // Boards were shipped with different sensors.
   // Welcome to the world of embedded systems.
   // Try to determine which sensor we have.
   // Scan through the possible sensor addresses
   /* Common I2C transaction setup */

   i2cTransaction.writeBuf = txBuffer;
   i2cTransaction.writeCount = 1;
   i2cTransaction.readBuf = rxBuffer;
   i2cTransaction.readCount = 0;
   found = false;
   for (i=0; i<3; ++i)
   {
       i2cTransaction.slaveAddress = sensors[i].address;
       txBuffer[0] = sensors[i].resultReg;
       DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));
       if (I2C_transfer(i2c, &i2cTransaction))
       {
           DISPLAY(snprintf(output, 64, "Found\n\r"));
           found = true;
           break;
       }
       DISPLAY(snprintf(output, 64, "No\n\r"));
   }
   if(found)
   {
       DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress));
   }
   else
   {
       DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"));
 }
}

int16_t readTemp(void)
{
 int j;
 int16_t temperature = 0;
 i2cTransaction.readCount = 2;
 if (I2C_transfer(i2c, &i2cTransaction))
 {
     /*
      * Extract degrees C from the received data;
      * see TMP sensor datasheet
      */
     temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
     temperature *= 0.0078125;
     /*
      * If the MSB is set '1', then we have a 2's complement
      * negative value which needs to be sign extended
      */
     if (rxBuffer[0] & 0x80)
     {
         temperature |= 0xF000;
     }
}
else
{
 DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status))
 DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"))
 }
 return temperature;
}

void initUART(void)
{
 UART_Params uartParams;
 // Init the driver
 UART_init();
 // Configure the driver
 UART_Params_init(&uartParams);
 uartParams.writeDataMode = UART_DATA_BINARY;
 uartParams.readDataMode = UART_DATA_BINARY;
 uartParams.readReturnMode = UART_RETURN_FULL;
 uartParams.baudRate = 115200;
 // Open the driver
 uart = UART_open(CONFIG_UART_0, &uartParams);
 if (uart == NULL) {
 /* UART_open() failed */
 while (1);
 }
}


//MAIN STARTS HERE

void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    //GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    //initialize everything

    initUART();
    initI2C();
    initTimer();

    //Initalize variables needed in main loop, will be updated in loop

    int currentTemp;   // current temp
    int setPoint = 28; // what we want the temp to be (close to room temp)
    int heat = 0;      // 1 or 0, 1 indicates heat on, etc.
    int seconds = 0;   // seconds occured (1s = 1000ms)
    int timer = 0;

    // and then implement

    while(1)
    {
        // Use TMP006 temp sensor to read the room temperature (I2C)
        //every 200ms check button flags
        //Two buttons increase and decrease set temp (GPIO interupt)

        if((timer%2)== 0){

            if (button0){
                //increment set point temp when this button is pressed
                setPoint++;
                //set button back to zero after button press is utilized
                button0 = 0;
            }

            if (button1){
                //decrement set point temp when this button is pressed
                setPoint--;
                //set button back to zero after button press is utilized
                button1 = 0;
            }
        }

        //every 500ms read temperature and update the LED
        //LED indicates output temp, where LED on = heat (GPIO)
        if(timer%5 == 0){

            //use Read Temp method to read temp, and save it as a new variable
            //This will update every 500 ms
            currentTemp = readTemp();

            if (currentTemp >= setPoint){
                //LED off when current temp is more or equal to set, heat off
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                //heat is off
                heat = 0;
            }

            if (currentTemp < setPoint){
                //LED on when current is is less then set, Heat on
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                //heat is on
                heat = 1;
            }
        }
        // UART simulates data being sent to server
        // Every second ouput the following to UART: Current temp in celsius, set temp, heat (on/off), and seconds running
        if (timer%10 == 0){
            DISPLAY( snprintf(output, 64, "<%02d, %02d, %d, %04d>\n\r", currentTemp, setPoint, heat, seconds))
            seconds++;
        }In

        //Remember to configure the timer period
        //timer is incrementing every loop

         while(!TimerFlag){} //Wait for timer period
         TimerFlag = 0;      //Lower flag raised by timer
         ++timer;            //increment timer
    }

}

